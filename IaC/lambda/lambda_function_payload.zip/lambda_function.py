import json
import boto3

# Initialize a session using Amazon DynamoDB
dynamodb = boto3.resource('dynamodb')

# Select your DynamoDB table
table = dynamodb.Table('counter-keeper-for-crc')

def lambda_handler(event, context):
    # Get the current count from the DynamoDB table
    response = table.get_item(
        Key={
            'Count': 0  # Assuming 'Count' is the primary key and its initial value is 0
        }
    )
    
    # Check if the item exists
    if 'Item' in response:
        current_count = int(response['Item']['Count'])
    else:
        # If the item doesn't exist, initialize it
        current_count = 0

    # Increment the count
    new_count = current_count + 1

    # Update the item in the DynamoDB table
    table.put_item(
        Item={
            'Count': new_count
        }
    )

    # Return the new count
    return {
        'statusCode': 200,
        'body': json.dumps({'new_count': new_count})
    }